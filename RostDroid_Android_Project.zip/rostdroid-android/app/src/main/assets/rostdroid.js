/* RostDroid 1.0 · offline simulator · no external JavaScript dependencies */
(() => {
  'use strict';

  const $ = id => document.getElementById(id);
  const esc = text => String(text ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const stored = (key, fallback) => { try { const result = JSON.parse(localStorage.getItem('rd_' + key)); return result === null ? fallback : result; } catch { return fallback; } };
  const save = (key, value) => { try { localStorage.setItem('rd_' + key, JSON.stringify(value)); return true; } catch { toast('Не удалось сохранить данные'); return false; } };
  const initialPreferences = { wallpaper:'aurora', accent:'violet', brightness:100, sound:true, focus:false };
  let prefs = {...initialPreferences, ...stored('prefs', {})};
  let notes = stored('notes', []);
  let tasks = stored('tasks', []);
  let events = stored('events', {});
  let activeApp = null;
  let currentCalendar = new Date();
  let selectedCalendarDay = null;
  let currentClockTab = 'time';
  let calcExpression = '';
  let currentNoteId = null;
  let stopwatchElapsed = 0, stopwatchStartAt = 0, stopwatchRunning = false;
  let timerRemaining = 60000, timerEndAt = 0, timerRunning = false;
  let musicContext = null, musicPlaying = false, musicHandle = null;
  let toastHandle = null;

  const applications = [
    {id:'phone',label:'Телефон',emoji:'☎',c1:'#40c99f',c2:'#138365',native:true},
    {id:'browser',label:'Браузер',emoji:'🌐',c1:'#64bafe',c2:'#5364e7',native:true},
    {id:'messages',label:'Сообщения',emoji:'✉',c1:'#5e9cf1',c2:'#356cca',native:true},
    {id:'camera',label:'Камера',emoji:'◎',c1:'#697388',c2:'#28344d',native:true},
    {id:'gallery',label:'Галерея',emoji:'✿',c1:'#f19ac0',c2:'#b56bc2',native:true},
    {id:'playstore',label:'Google Play',emoji:'▶',c1:'#4fd9a8',c2:'#3c87d7',native:true},
    {id:'settings',label:'Настройки',emoji:'⚙',c1:'#8d9aae',c2:'#4b6d88'},
    {id:'notes',label:'Заметки',emoji:'▤',c1:'#f9c873',c2:'#f19b5f'},
    {id:'calculator',label:'Калькулятор',emoji:'▦',c1:'#817df7',c2:'#5759b7'},
    {id:'calendar',label:'Календарь',emoji:'▣',c1:'#fb92a4',c2:'#dc5685'},
    {id:'clock',label:'Часы',emoji:'◷',c1:'#5681bd',c2:'#1e335c'},
    {id:'tasks',label:'Задачи',emoji:'✓',c1:'#72dcc9',c2:'#329a95'},
    {id:'files',label:'Файлы',emoji:'▰',c1:'#f1b65c',c2:'#dc8848',native:true},
    {id:'contacts',label:'Контакты',emoji:'♟',c1:'#598ed5',c2:'#3c62aa',native:true},
    {id:'music',label:'Музыка',emoji:'♫',c1:'#d27cf8',c2:'#8554d7'},
    {id:'maps',label:'Карты',emoji:'⌖',c1:'#71c998',c2:'#4e9d7b',native:true},
    {id:'weather',label:'Погода',emoji:'☀',c1:'#7abcf3',c2:'#4e8cbe'},
    {id:'draw',label:'Рисование',emoji:'✎',c1:'#fb9f8d',c2:'#c16b9e'},
    {id:'about',label:'О системе',emoji:'✦',c1:'#8784fe',c2:'#5479bf'}
  ];
  const byId = Object.fromEntries(applications.map(a => [a.id, a]));

  function toast(message) {
    let node = $('toast');
    if (!node) {
      node = document.createElement('div'); node.id = 'toast';
      Object.assign(node.style,{position:'absolute',zIndex:'100',left:'50%',bottom:'60px',transform:'translateX(-50%)',background:'#e9f7ff',color:'#15314b',padding:'11px 19px',borderRadius:'18px',fontSize:'12px',fontWeight:'700',boxShadow:'0 10px 30px #0006',maxWidth:'90%',textAlign:'center',transition:'opacity .2s'});
      $('phone').appendChild(node);
    }
    node.textContent = message; node.style.opacity = '1'; clearTimeout(toastHandle);
    toastHandle = setTimeout(() => node.style.opacity = '0', 2200);
  }

  function iconMarkup(app) {
    return `<button class="app-icon" data-open="${app.id}" title="${esc(app.label)}"><span class="icon-badge" style="--ic1:${app.c1};--ic2:${app.c2}">${app.emoji}</span><span class="icon-label">${esc(app.label)}</span></button>`;
  }
  $('homeIcons').innerHTML = ['playstore','gallery','notes','calendar','calculator','clock','settings','files'].map(id => iconMarkup(byId[id])).join('');
  $('dockIcons').innerHTML = ['phone','browser','messages','camera'].map(id => iconMarkup(byId[id])).join('');
  $('drawerIcons').innerHTML = applications.map(iconMarkup).join('');

  function showHome() {
    activeApp = null;
    closeDialog();
    $('appWindow').classList.add('hidden');
    $('drawer').classList.add('hidden');
    $('shade').classList.add('hidden');
    $('appSearch').value = '';
    $('drawerIcons').innerHTML = applications.map(iconMarkup).join('');
    updateNotesCount();
    stopMusic();
  }
  function updateNotesCount() { $('notesCount').textContent = `${notes.length} ${plural(notes.length, 'заметка','заметки','заметок')}`; }
  function plural(n,a,b,c) { const i=Math.abs(n)%100, j=i%10; return i>10&&i<20?c:j>1&&j<5?b:j===1?a:c; }
  function openDrawer() { $('shade').classList.add('hidden'); $('drawer').classList.remove('hidden'); $('appSearch').focus(); }
  function openShade() { $('drawer').classList.add('hidden'); $('shade').classList.remove('hidden'); }

  function nativeOpen(id, value='') {
    if (window.RostAndroid && typeof window.RostAndroid.open === 'function') {
      window.RostAndroid.open(id, value);
    } else {
      const hints = {browser:'В APK откроется настоящий браузер',playstore:'Google Play откроется, если он установлен на телефоне',phone:'В APK откроется набор номера',camera:'В APK откроется камера Android',files:'В APK откроется выбор файлов'};
      toast(hints[id] || 'Эта кнопка работает в Android APK');
    }
  }
  function openApp(id) {
    const app = byId[id]; if (!app) return;
    $('drawer').classList.add('hidden'); $('shade').classList.add('hidden');
    if (app.native) { nativeOpen(id); return; }
    if (activeApp === 'music' && id !== 'music') stopMusic();
    activeApp = id;
    $('appTitle').textContent = app.label;
    $('appWindow').classList.remove('hidden');
    $('appBody').scrollTop = 0;
    ({settings:renderSettings,notes:renderNotes,calculator:renderCalculator,
      calendar:renderCalendar,clock:renderClock,tasks:renderTasks,music:renderMusic,
      weather:renderWeather,draw:renderDraw,about:renderAbout})[id]?.();
  }
  function page(html) { $('appBody').innerHTML = html; }

  function closeDialog() { $('dialog').classList.add('hidden'); $('dialogContent').innerHTML = ''; $('dialogActions').innerHTML = ''; }
  function dialog(title, body, actions) {
    $('dialogContent').innerHTML = `<h3>${esc(title)}</h3>${body}`;
    $('dialogActions').innerHTML = '';
    actions.forEach(action => {
      const button=document.createElement('button'); button.className='btn '+(action.kind||'ghost'); button.textContent=action.label;
      button.onclick=() => { if (action.onClick) action.onClick(); else closeDialog(); };
      $('dialogActions').appendChild(button);
    });
    $('dialog').classList.remove('hidden');
  }
  function confirmDelete(title, onYes) { dialog(title,'<p>Это действие нельзя отменить.</p>',[{label:'Отмена'},{label:'Удалить',kind:'danger',onClick:()=>{onYes();closeDialog();}}]); }

  function updateDateTime() {
    const now=new Date();
    const hh=String(now.getHours()).padStart(2,'0'),mm=String(now.getMinutes()).padStart(2,'0');
    const t=`${hh}:${mm}`;
    const full=now.toLocaleDateString('ru-RU',{weekday:'long',day:'numeric',month:'long'});
    ['statusTime','heroTime','lockTime','shadeTime'].forEach(id => $(id).textContent=t);
    ['heroDate','lockDate','shadeDate'].forEach(id => $(id).textContent=full[0].toUpperCase()+full.slice(1));
    const activeClock=$('clockLiveTime'); if (activeClock) activeClock.textContent=now.toLocaleTimeString('ru-RU',{hour:'2-digit',minute:'2-digit',second:'2-digit'});
    const liveDate=$('clockLiveDate'); if(liveDate) liveDate.textContent=full;
  }

  function applyPreferences() {
    $('phone').className = 'phone wallpaper-' + (['aurora','sunset','forest','nebula'].includes(prefs.wallpaper) ? prefs.wallpaper : 'aurora');
    const accents={violet:['#a9a7ff','#69e2d4'],pink:['#ff9bc2','#f6c77d'],teal:['#7de8d1','#9ac8ff'],gold:['#ffda84','#ffc0a0']};
    const palette=accents[prefs.accent] || accents.violet;
    document.documentElement.style.setProperty('--accent',palette[0]);document.documentElement.style.setProperty('--accent2',palette[1]);
    document.documentElement.style.setProperty('--brightness', String(prefs.brightness / 100));
    $('brightnessQuick').value=prefs.brightness;$('brightValue').textContent=prefs.brightness+'%';
    $('qsSound').classList.toggle('selected',!!prefs.sound);$('qsFocus').classList.toggle('selected',!!prefs.focus);
  }

  function unlock() { $('lockScreen').classList.add('hidden'); $('desktop').classList.remove('hidden'); }
  let lockStartY=0;
  $('lockScreen').addEventListener('touchstart',e=>{lockStartY=e.touches[0].clientY},{passive:true});
  $('lockScreen').addEventListener('touchend',e=>{if(lockStartY-e.changedTouches[0].clientY>65)unlock()},{passive:true});
  $('unlock').onclick=unlock;
  $('lockFlash').onclick=()=>toast('Фонарик доступен в шторке Android');
  $('lockCamera').onclick=()=>nativeOpen('camera');
  $('statusBar').onclick=openShade;
  $('openAll').onclick=openDrawer;
  $('homeHandle').onclick=openDrawer;
  $('drawerClose').onclick=()=> $('drawer').classList.add('hidden');
  $('shadeClose').onclick=()=> $('shade').classList.add('hidden');
  $('appBack').onclick=()=>window.rostdroidBack();
  $('appClose').onclick=showHome;
  $('appHomeBar').onclick=showHome;
  $('qsWifi').onclick=()=>nativeOpen('wifi');
  $('qsBluetooth').onclick=()=>nativeOpen('bluetooth');
  $('qsSound').onclick=()=>{prefs.sound=!prefs.sound;save('prefs',prefs);applyPreferences();toast(prefs.sound?'Звук интерфейса включён':'Звук интерфейса выключен');};
  $('qsFocus').onclick=()=>{prefs.focus=!prefs.focus;save('prefs',prefs);applyPreferences();toast(prefs.focus?'Режим фокуса включён':'Режим фокуса выключен');};
  $('brightnessQuick').oninput=e=>{prefs.brightness=Number(e.target.value);save('prefs',prefs);applyPreferences();};
  $('appSearch').oninput=e=>{
    const query=e.target.value.toLocaleLowerCase('ru-RU').trim();
    $('drawerIcons').innerHTML=applications.filter(a=>a.label.toLocaleLowerCase('ru-RU').includes(query)).map(iconMarkup).join('') || '<p class="screen-lead">Ничего не найдено</p>';
  };
  document.addEventListener('click',e=>{ const item=e.target.closest('[data-open]'); if(item){openApp(item.dataset.open);} });
  document.addEventListener('keydown',e=>{if(e.key==='Escape'||e.key==='BrowserBack'){e.preventDefault();window.rostdroidBack();}});
  window.rostdroidBack=() => {
    if(!$('dialog').classList.contains('hidden'))return closeDialog();
    if(!$('shade').classList.contains('hidden'))return $('shade').classList.add('hidden');
    if(!$('drawer').classList.contains('hidden'))return $('drawer').classList.add('hidden');
    if(!$('appWindow').classList.contains('hidden'))return showHome();
    if(!$('desktop').classList.contains('hidden')){ $('desktop').classList.add('hidden'); $('lockScreen').classList.remove('hidden'); return; }
    unlock();
  };

  function renderAbout() {
    page(`<div class="info-logo">R</div><h2 class="info-title">RostDroid OS</h2><p class="info-sub">Твоя система. Твой стиль. Твой мир.</p>
      <div class="card"><h3>Информация</h3><div class="info-detail"><span>Версия</span><strong>RostDroid 1.0</strong></div><div class="info-detail"><span>Платформа</span><strong>Android Simulator</strong></div><div class="info-detail"><span>Разработчик</span><strong>Ростислав ✦</strong></div><div class="info-detail"><span>Режим</span><strong>Офлайн + Android</strong></div></div>
      <div class="card"><h3>Что это такое?</h3><p>RostDroid — приложение, которое выглядит как собственная телефонная система. Это не замена Android. Заметки, календарь, часы, калькулятор, задачи и рисование работают внутри симулятора. Браузер и другие кнопки открывают функции твоего телефона.</p></div>
      <button class="btn" data-open="settings">Настроить RostDroid →</button>`);
  }

  function renderWeather() {
    page(`<p class="screen-eyebrow">ПОГОДА · ДЕМО</p><div class="card" style="text-align:center;background:linear-gradient(145deg,#517fcd,#246179);padding:35px 18px"><div style="font-size:76px">☀</div><h1 style="font-size:66px;margin:6px 0;letter-spacing:-3px">21°</h1><p style="color:#fff;font-size:16px">Солнечно</p><p style="font-size:11px;margin-top:10px">Это демонстрационные данные, не настоящий прогноз</p></div>
      <div class="card"><h3>Прогноз</h3><p>Чтобы узнать настоящую погоду, открой браузер и найди прогноз для своего города.</p><div class="btn-row"><button class="btn" data-open="browser">Открыть браузер ↗</button></div></div>`);
  }

  function renderSettings() {
    page(`<p class="screen-eyebrow">РОСТДРОИД / ПЕРСОНАЛИЗАЦИЯ</p><h2 class="screen-heading">Это твой мир ✦</h2><p class="screen-lead">Выбери оформление, удобное именно тебе.</p>
      <div class="setting-section">ОБОИ</div><div class="wallpaper-options">${[['aurora','Аврора'],['sunset','Закат'],['forest','Лес'],['nebula','Космос']].map(([id,name])=>`<button class="wallpaper-choice ${id} ${prefs.wallpaper===id?'active':''}" data-wallpaper="${id}"><span>${name}</span></button>`).join('')}</div>
      <div class="setting-section">ЦВЕТ СИСТЕМЫ</div><div class="accent-swatches">${[['violet','#8788ed'],['pink','#ef85bd'],['teal','#67d6be'],['gold','#f4c27b']].map(([id,color])=>`<button class="swatch ${prefs.accent===id?'active':''}" data-accent="${id}" style="--swatch:${color}" aria-label="Цвет ${id}">${prefs.accent===id?'✓':''}</button>`).join('')}</div>
      <div class="setting-section">ПАРАМЕТРЫ</div><div class="setting-row"><div><strong>Яркость интерфейса</strong><small>Меняет вид обоев в RostDroid</small></div><span class="row-value">${prefs.brightness}%</span></div><input type="range" id="settingsBrightness" min="65" max="120" value="${prefs.brightness}" style="width:100%;accent-color:#77e0cb;margin-top:14px">
      <div class="setting-row"><div><strong>Звуки интерфейса</strong><small>Сигнал таймера и звуки музыки</small></div><button class="switch ${prefs.sound?'on':''}" id="settingSound" aria-label="Включить звук"></button></div>
      <div class="setting-row"><div><strong>Режим фокуса</strong><small>Визуальный переключатель симулятора</small></div><button class="switch ${prefs.focus?'on':''}" id="settingFocus" aria-label="Режим фокуса"></button></div>
      <div class="setting-section">ТВОЙ ANDROID</div><button class="list-row" id="systemSettings"><span class="row-icon">⚙</span><span class="row-main"><strong>Настройки телефона</strong><small>Открыть настоящие настройки Android</small></span><span class="chevron">↗</span></button>
      <button class="list-row" data-open="about"><span class="row-icon">✦</span><span class="row-main"><strong>О системе RostDroid</strong><small>Версия, платформа, информация</small></span><span class="chevron">›</span></button>`);
    document.querySelectorAll('[data-wallpaper]').forEach(b=>b.onclick=()=>{prefs.wallpaper=b.dataset.wallpaper;save('prefs',prefs);applyPreferences();renderSettings();});
    document.querySelectorAll('[data-accent]').forEach(b=>b.onclick=()=>{prefs.accent=b.dataset.accent;save('prefs',prefs);applyPreferences();renderSettings();});
    $('settingsBrightness').oninput=e=>{prefs.brightness=Number(e.target.value);save('prefs',prefs);applyPreferences();const val=document.querySelector('.setting-row .row-value');if(val)val.textContent=prefs.brightness+'%';};
    $('settingSound').onclick=()=>{prefs.sound=!prefs.sound;save('prefs',prefs);applyPreferences();renderSettings();};
    $('settingFocus').onclick=()=>{prefs.focus=!prefs.focus;save('prefs',prefs);applyPreferences();renderSettings();};
    $('systemSettings').onclick=()=>nativeOpen('settings');
  }

  function renderNotes() {
    currentNoteId=null;
    const sorted=[...notes].sort((a,b)=>b.updated-a.updated);
    page(`<p class="screen-eyebrow">ТВОИ ИДЕИ</p><h2 class="screen-heading">Запомни момент ✍</h2><p class="screen-lead">Заметки сохраняются на этом устройстве.</p>
      <button class="btn" id="newNote">+ Новая заметка</button><div style="margin-top:22px">${sorted.length?sorted.map(n=>`<button class="list-row" data-note-id="${esc(n.id)}"><span class="row-icon">▤</span><span class="row-main"><strong>${esc(n.title || 'Без названия')}</strong><small>${esc(n.text||'Пустая заметка')}</small></span><span class="chevron">›</span></button>`).join(''):'<div class="empty-state"><b>✎</b><h3>Здесь пока пусто</h3><p>Запиши идею, важную мысль или секретный план.</p></div>'}</div>`);
    $('newNote').onclick=()=>renderNoteEditor(null);
    document.querySelectorAll('[data-note-id]').forEach(b=>b.onclick=()=>renderNoteEditor(b.dataset.noteId));
    updateNotesCount();
  }
  function renderNoteEditor(id) {
    currentNoteId=id;
    const n=notes.find(v=>v.id===id) || {title:'',text:''};
    page(`<p class="screen-eyebrow">${id?'РЕДАКТИРОВАНИЕ':'НОВАЯ ЗАМЕТКА'}</p><label class="form-label" for="noteTitle">НАЗВАНИЕ</label><input class="form-input" id="noteTitle" maxlength="90" placeholder="Например, Мои идеи" value="${esc(n.title)}"><label class="form-label" for="noteText">ТЕКСТ</label><textarea class="form-textarea" id="noteText" maxlength="5000" placeholder="Начни писать здесь…">${esc(n.text)}</textarea><div class="btn-row"><button class="btn" id="saveNote">✓ Сохранить</button><button class="btn ghost" id="cancelNote">Назад</button>${id?'<button class="btn danger" id="deleteNote">Удалить</button>':''}</div>`);
    $('saveNote').onclick=()=>{
      const title=$('noteTitle').value.trim(),text=$('noteText').value.trim();
      if(!title&&!text){toast('Напиши хотя бы что-нибудь');return;}
      if(id){const existing=notes.find(v=>v.id===id);if(existing)Object.assign(existing,{title,text,updated:Date.now()});}
      else notes.push({id:String(Date.now())+'-'+Math.floor(Math.random()*10000),title,text,updated:Date.now()});
      if(save('notes',notes)){renderNotes();toast('Заметка сохранена ✓');}
    };
    $('cancelNote').onclick=renderNotes;
    if(id)$('deleteNote').onclick=()=>confirmDelete('Удалить заметку?',()=>{notes=notes.filter(v=>v.id!==id);save('notes',notes);renderNotes();toast('Заметка удалена');});
  }

  function renderTasks() {
    const complete=tasks.filter(t=>t.done).length;
    page(`<p class="screen-eyebrow">ТВОИ ПЛАНЫ</p><h2 class="screen-heading">Мои задачи ✓</h2><p class="screen-lead">Выполнено ${complete} из ${tasks.length}. Всё получится!</p>
      <div class="card"><label class="form-label" for="taskInput" style="margin-top:0">ДОБАВИТЬ ЗАДАЧУ</label><div style="display:flex;gap:8px"><input id="taskInput" maxlength="160" class="form-input" placeholder="Что сделать?" style="flex:1;min-width:0"><button class="btn" id="addTask">+</button></div></div>
      <div class="setting-section">СПИСОК</div>${tasks.length?tasks.map(task=>`<div class="list-row"><button class="todo-check ${task.done?'checked':''}" data-task-check="${esc(task.id)}">${task.done?'✓':''}</button><span class="row-main ${task.done?'completed':''}"><strong>${esc(task.text)}</strong></span><button data-task-remove="${esc(task.id)}" class="chevron" aria-label="Удалить задачу">×</button></div>`).join(''):'<div class="empty-state"><b>☑</b><h3>Свободное время!</h3><p>Добавь первую задачу, чтобы ничего не забыть.</p></div>'}`);
    const add=()=>{const text=$('taskInput').value.trim();if(!text)return;tasks.unshift({id:String(Date.now())+'-'+Math.random().toString(36).slice(2,6),text,done:false});save('tasks',tasks);renderTasks();};
    $('addTask').onclick=add;$('taskInput').onkeydown=e=>{if(e.key==='Enter')add()};
    document.querySelectorAll('[data-task-check]').forEach(b=>b.onclick=()=>{const t=tasks.find(t=>t.id===b.dataset.taskCheck);if(t){t.done=!t.done;save('tasks',tasks);renderTasks();}});
    document.querySelectorAll('[data-task-remove]').forEach(b=>b.onclick=()=>{tasks=tasks.filter(t=>t.id!==b.dataset.taskRemove);save('tasks',tasks);renderTasks();});
  }

  function renderCalculator() {
    page(`<p class="screen-eyebrow">БЫСТРЫЕ ВЫЧИСЛЕНИЯ</p><div class="calculator-display"><div class="calculator-expression" id="calcExpression">${esc(calcExpression) || '&nbsp;'}</div><div class="calculator-result" id="calcResult">${calcExpression?esc(calcPreview(calcExpression)):'0'}</div></div>
      <div class="calculator-grid">${['AC','(',')','÷','7','8','9','×','4','5','6','−','1','2','3','+','±','0','.','='].map(val=>`<button data-calc="${esc(val)}" class="${val==='='?'equals':['AC','±'].includes(val)?'special':['÷','×','−','+','(',')'].includes(val)?'operator':''}">${val}</button>`).join('')}</div><p class="screen-lead" style="text-align:center;margin-top:18px">Можно считать даже без интернета.</p>`);
    document.querySelectorAll('[data-calc]').forEach(button=>button.onclick=()=>{
      const val=button.dataset.calc;
      if(val==='AC')calcExpression='';
      else if(val==='='){
        try { const result=evaluate(calcExpression); calcExpression=String(Number(result.toPrecision(11))); }
        catch { toast('Проверь выражение'); }
      } else if(val==='±'){
        if(calcExpression.startsWith('−'))calcExpression=calcExpression.slice(1);
        else calcExpression='−'+calcExpression;
      } else if(calcExpression.length<65)calcExpression+=val;
      $('calcExpression').textContent=calcExpression||' ';
      $('calcResult').textContent=calcExpression?calcPreview(calcExpression):'0';
    });
  }
  function calcPreview(expression) {
    try {const result=evaluate(expression);return String(Number(result.toPrecision(10)));} catch {return '…';}
  }
  function evaluate(input) {
    const expression=input.replace(/×/g,'*').replace(/÷/g,'/').replace(/−/g,'-');
    const chunks=expression.match(/\d+(?:\.\d*)?|\.\d+|[()+\-*/]/g) || [];
    if(chunks.join('')!==expression || chunks.length>120 || chunks.length===0)throw Error('Недопустимое выражение');
    let i=0;
    function factor() {
      if(chunks[i]==='+'){i++;return factor()}
      if(chunks[i]==='-'){i++;return -factor()}
      if(chunks[i]==='('){i++;const value=expr();if(chunks[i++]!==')')throw Error('Скобки');return value}
      if(i>=chunks.length||!/^(\d|\.)/.test(chunks[i]))throw Error('Число');
      const value=Number(chunks[i++]);if(!Number.isFinite(value))throw Error('Не число');return value;
    }
    function term(){let v=factor();while(chunks[i]==='*'||chunks[i]==='/'){const op=chunks[i++],rhs=factor();v=op==='*'?v*rhs:v/rhs;}return v;}
    function expr(){let v=term();while(chunks[i]==='+'||chunks[i]==='-'){const op=chunks[i++],rhs=term();v=op==='+'?v+rhs:v-rhs;}return v;}
    const result=expr();if(i!==chunks.length||!Number.isFinite(result))throw Error('Ошибка вычисления');return result;
  }

  function dateKey(year,month,day){return `${year}-${String(month+1).padStart(2,'0')}-${String(day).padStart(2,'0')}`;}
  function renderCalendar() {
    const year=currentCalendar.getFullYear(),month=currentCalendar.getMonth();
    const now=new Date(),today=dateKey(now.getFullYear(),now.getMonth(),now.getDate());
    const first=(new Date(year,month,1).getDay()+6)%7;
    const days=new Date(year,month+1,0).getDate();
    if(!selectedCalendarDay || !selectedCalendarDay.startsWith(`${year}-${String(month+1).padStart(2,'0')}-`))selectedCalendarDay=dateKey(year,month,Math.min(days,now.getMonth()===month&&now.getFullYear()===year?now.getDate():1));
    const monthTitle=new Date(year,month,1).toLocaleDateString('ru-RU',{month:'long',year:'numeric'});
    const cells=[];
    for(let cell=0;cell<42;cell++){
      const day=cell-first+1;
      const date=new Date(year,month,day);
      const key=dateKey(date.getFullYear(),date.getMonth(),date.getDate());
      cells.push(`<button data-day="${key}" class="calendar-day ${date.getMonth()!==month?'other':''} ${key===today?'today':''} ${key===selectedCalendarDay?'selected':''} ${events[key]?.length?'event':''}">${date.getDate()}</button>`);
    }
    const dayEvents=events[selectedCalendarDay]||[];
    page(`<p class="screen-eyebrow">ТВОЁ РАСПИСАНИЕ</p><h2 class="screen-heading">Календарь</h2><p class="screen-lead">Добавляй свои события и планы.</p>
      <div class="card"><div class="calendar-top"><button id="prevMonth">‹</button><strong>${esc(monthTitle)}</strong><button id="nextMonth">›</button></div><div class="calendar-grid">${['Пн','Вт','Ср','Чт','Пт','Сб','Вс'].map(d=>`<span class="calendar-weekday">${d}</span>`).join('')}${cells.join('')}</div></div>
      <div class="setting-section">СОБЫТИЯ · ${esc(new Date(selectedCalendarDay+'T12:00:00').toLocaleDateString('ru-RU',{day:'numeric',month:'long'}))}</div>
      ${dayEvents.map((event,index)=>`<div class="list-row"><span class="row-icon">✦</span><span class="row-main"><strong>${esc(event)}</strong></span><button class="chevron" data-event-delete="${index}" aria-label="Удалить событие">×</button></div>`).join('')}
      <div class="card" style="margin-top:15px"><label class="form-label" for="eventInput" style="margin-top:0">НОВОЕ СОБЫТИЕ</label><input id="eventInput" class="form-input" maxlength="160" placeholder="Например, День рождения"><div class="btn-row"><button class="btn" id="addEvent">+ Добавить</button></div></div>`);
    $('prevMonth').onclick=()=>{currentCalendar=new Date(year,month-1,1);selectedCalendarDay=null;renderCalendar()};
    $('nextMonth').onclick=()=>{currentCalendar=new Date(year,month+1,1);selectedCalendarDay=null;renderCalendar()};
    document.querySelectorAll('[data-day]').forEach(b=>b.onclick=()=>{selectedCalendarDay=b.dataset.day;const d=new Date(selectedCalendarDay+'T12:00:00');currentCalendar=new Date(d.getFullYear(),d.getMonth(),1);renderCalendar();});
    const add=()=>{const value=$('eventInput').value.trim();if(!value)return;events[selectedCalendarDay]=[...(events[selectedCalendarDay]||[]),value];save('events',events);renderCalendar();toast('Событие добавлено ✓');};
    $('addEvent').onclick=add;$('eventInput').onkeydown=e=>{if(e.key==='Enter')add();};
    document.querySelectorAll('[data-event-delete]').forEach(b=>b.onclick=()=>{events[selectedCalendarDay].splice(Number(b.dataset.eventDelete),1);if(events[selectedCalendarDay].length===0)delete events[selectedCalendarDay];save('events',events);renderCalendar();});
  }

  function renderClock() {
    page(`<p class="screen-eyebrow">ВРЕМЯ ROSTDROID</p><div class="clock-tabs">${[['time','Часы'],['stopwatch','Секундомер'],['timer','Таймер']].map(([id,label])=>`<button data-clock-tab="${id}" class="${currentClockTab===id?'active':''}">${label}</button>`).join('')}</div><div id="clockPanel"></div>`);
    document.querySelectorAll('[data-clock-tab]').forEach(b=>b.onclick=()=>{currentClockTab=b.dataset.clockTab;renderClock();});
    renderClockPanel();
  }
  function formatMs(ms) { const seconds=Math.floor(Math.max(0,ms)/1000);return `${String(Math.floor(seconds/60)).padStart(2,'0')}:${String(seconds%60).padStart(2,'0')}.${String(Math.floor((Math.max(0,ms)%1000)/100)).padStart(1,'0')}`; }
  function renderClockPanel() {
    if(currentClockTab==='time') {
      $('clockPanel').innerHTML=`<div class="clock-time" id="clockLiveTime"></div><div class="clock-date" id="clockLiveDate"></div><div class="card"><h3>Сегодня — отличный день ✨</h3><p>Время твоего телефона отображается в реальном времени.</p></div>`;
      updateDateTime();
    } else if(currentClockTab==='stopwatch') {
      $('clockPanel').innerHTML=`<div class="stopwatch-number" id="stopwatchDisplay">${formatMs(stopwatchElapsed)}</div><div class="center-actions"><button id="swStart" class="btn">${stopwatchRunning?'Пауза':'Старт'}</button><button id="swReset" class="btn ghost">Сброс</button></div><p class="screen-lead" style="text-align:center;margin-top:35px">Отмеряй время для спорта, игр и других дел.</p>`;
      $('swStart').onclick=()=>{if(stopwatchRunning){stopwatchElapsed=Date.now()-stopwatchStartAt;stopwatchRunning=false;}else{stopwatchStartAt=Date.now()-stopwatchElapsed;stopwatchRunning=true;}renderClockPanel()};
      $('swReset').onclick=()=>{stopwatchRunning=false;stopwatchElapsed=0;renderClockPanel();};
    } else {
      $('clockPanel').innerHTML=`<div class="timer-number" id="timerDisplay">${formatMs(timerRemaining)}</div><div class="timer-inputs"><label>МИНУТЫ<input class="form-input" id="timerMinutes" type="number" min="0" max="180" value="1"></label><label>СЕКУНДЫ<input class="form-input" id="timerSeconds" type="number" min="0" max="59" value="0"></label></div><div class="center-actions" style="margin-top:26px"><button class="btn" id="timerStart">${timerRunning?'Пауза':'Старт'}</button><button class="btn ghost" id="timerReset">Сброс</button></div>`;
      $('timerStart').onclick=()=>{
        if(timerRunning){timerRemaining=Math.max(0,timerEndAt-Date.now());timerRunning=false;}
        else {
          if(timerRemaining<=0 || timerRemaining===60000){const m=Math.max(0,Math.min(180,Number($('timerMinutes').value)||0)),s=Math.max(0,Math.min(59,Number($('timerSeconds').value)||0));timerRemaining=(m*60+s)*1000;}
          if(timerRemaining<=0){toast('Задай время таймера');return;}
          timerEndAt=Date.now()+timerRemaining;timerRunning=true;
        }
        renderClockPanel();
      };
      $('timerReset').onclick=()=>{timerRunning=false;timerRemaining=60000;renderClockPanel();};
    }
  }
  function tickTimers() {
    if(stopwatchRunning){stopwatchElapsed=Date.now()-stopwatchStartAt;const el=$('stopwatchDisplay');if(el)el.textContent=formatMs(stopwatchElapsed);}
    if(timerRunning){timerRemaining=Math.max(0,timerEndAt-Date.now());const el=$('timerDisplay');if(el)el.textContent=formatMs(timerRemaining);
      if(timerRemaining===0){timerRunning=false;if(prefs.sound)playTone(850,.24,.14);toast('⏰ Время вышло!');if(activeApp==='clock'&&currentClockTab==='timer')renderClockPanel();}
    }
  }

  function playTone(frequency,duration=.15,volume=.07) {
    if(!prefs.sound)return;
    try{
      const AudioContext=window.AudioContext||window.webkitAudioContext;
      if(!AudioContext)return;
      if(!musicContext)musicContext=new AudioContext();
      if(musicContext.state==='suspended')musicContext.resume();
      const osc=musicContext.createOscillator(),gain=musicContext.createGain();
      osc.type='sine';osc.frequency.value=frequency;gain.gain.setValueAtTime(volume,musicContext.currentTime);
      gain.gain.exponentialRampToValueAtTime(.001,musicContext.currentTime+duration);
      osc.connect(gain);gain.connect(musicContext.destination);osc.start();osc.stop(musicContext.currentTime+duration+.01);
    }catch{}
  }

  function stopMusic(){if(musicHandle)clearInterval(musicHandle);musicHandle=null;musicPlaying=false;}
  function renderMusic() {
    page(`<p class="screen-eyebrow">ROSTDROID MUSIC STUDIO</p><div class="music-hero"><div class="music-art">♫</div><h3>Звёздная мелодия</h3><p>Встроенный синтезатор · работает офлайн</p><div class="music-controls"><button id="prevTrack">|◀</button><button class="play" id="musicPlay">${musicPlaying?'Ⅱ':'▶'}</button><button id="nextTrack">▶|</button></div></div>
      <div class="card"><h3>Играй свою музыку</h3><p>Нажимай на ноты, чтобы сочинить мелодию.</p><div class="calculator-grid" style="grid-template-columns:repeat(4,1fr);margin-top:18px">${[262,294,330,349,392,440,494,523].map((freq,i)=>`<button data-note="${freq}" style="height:62px;background:${i%2?'#465c88':'#6781b5'};border-radius:13px;font-size:14px">${['До','Ре','Ми','Фа','Соль','Ля','Си','До+'][i]}</button>`).join('')}</div></div><p class="screen-lead">Это не музыкальный стриминг, а маленькая музыкальная студия в RostDroid.</p>`);
    const melody=[392,440,523,440,392,330,349,392,294,330,392,349,330,294,262,330];
    function toggle(){
      if(musicPlaying){stopMusic();$('musicPlay').textContent='▶';return;}
      let i=0;musicPlaying=true;$('musicPlay').textContent='Ⅱ';playTone(melody[i++],.27,.07);
      musicHandle=setInterval(()=>{playTone(melody[i++%melody.length],.27,.07);},360);
    }
    $('musicPlay').onclick=toggle;
    $('prevTrack').onclick=()=>{playTone(330,.3,.11);};
    $('nextTrack').onclick=()=>{playTone(523,.3,.11);};
    document.querySelectorAll('[data-note]').forEach(b=>b.onclick=()=>playTone(Number(b.dataset.note),.45,.12));
  }

  function renderDraw() {
    const previous=stored('art',null);
    const safePrevious=typeof previous==='string'&&/^data:image\/png;base64,[a-zA-Z0-9+/=]+$/.test(previous)?previous:null;
    page(`<p class="screen-eyebrow">ТВОРЧЕСТВО</p><h2 class="screen-heading">Рисуй что угодно ✎</h2><p class="screen-lead">Рисунок можно сохранить внутри RostDroid.</p>
      <div class="card" style="padding:9px"><canvas id="drawCanvas" width="700" height="700" style="display:block;width:100%;aspect-ratio:1;background:#f6f8fe;border-radius:16px;touch-action:none"></canvas></div>
      <div class="accent-swatches" style="justify-content:center">${[['#222d48','Чёрный'],['#8273f1','Фиолетовый'],['#ed779b','Розовый'],['#58b6a4','Бирюзовый'],['#e9a24b','Жёлтый']].map(([color,name],index)=>`<button class="swatch ${index===0?'active':''}" data-paint="${color}" style="--swatch:${color}" aria-label="${name}"></button>`).join('')}</div>
      <div class="center-actions"><button id="clearDrawing" class="btn ghost">Очистить</button><button id="saveDrawing" class="btn">Сохранить ✓</button></div>
      <div class="setting-section">ПОСЛЕДНИЙ РИСУНОК</div><div id="savedDrawing">${safePrevious?`<img src="${safePrevious}" alt="Последний рисунок" style="width:100%;border-radius:18px;border:1px solid #ffffff35">`:'<p class="screen-lead">Пока ничего не сохранено</p>'}</div>`);
    const canvas=$('drawCanvas'),ctx=canvas.getContext('2d');
    ctx.fillStyle='#f6f8fe';ctx.fillRect(0,0,canvas.width,canvas.height);
    ctx.lineWidth=9;ctx.lineCap='round';ctx.lineJoin='round';ctx.strokeStyle='#222d48';
    let painting=false;
    function pos(e){const r=canvas.getBoundingClientRect();return{x:(e.clientX-r.left)/r.width*canvas.width,y:(e.clientY-r.top)/r.height*canvas.height};}
    canvas.addEventListener('pointerdown',e=>{painting=true;canvas.setPointerCapture(e.pointerId);const p=pos(e);ctx.beginPath();ctx.moveTo(p.x,p.y);ctx.lineTo(p.x+.01,p.y+.01);ctx.stroke();});
    canvas.addEventListener('pointermove',e=>{if(!painting)return;const p=pos(e);ctx.lineTo(p.x,p.y);ctx.stroke();});
    canvas.addEventListener('pointerup',()=>{painting=false;});canvas.addEventListener('pointercancel',()=>{painting=false;});
    document.querySelectorAll('[data-paint]').forEach(b=>b.onclick=()=>{ctx.strokeStyle=b.dataset.paint;document.querySelectorAll('[data-paint]').forEach(c=>c.classList.remove('active'));b.classList.add('active');});
    $('clearDrawing').onclick=()=>{ctx.fillStyle='#f6f8fe';ctx.fillRect(0,0,canvas.width,canvas.height);};
    $('saveDrawing').onclick=()=>{const data=canvas.toDataURL('image/png');if(save('art',data)){$('savedDrawing').innerHTML=`<img src="${data}" alt="Последний рисунок" style="width:100%;border-radius:18px;border:1px solid #ffffff35">`;toast('Рисунок сохранён ✓');}};
  }

  // A complete restart always shows the animated RostDroid boot screen.
  applyPreferences();
  updateNotesCount();
  updateDateTime();
  setInterval(updateDateTime,1000);
  setInterval(tickTimers,100);
  const bootSteps=['Запускаем систему…','Подключаем приложения…','Настраиваем твой мир…','Всё готово!'];
  let bootPercent=0;
  const bootInterval=setInterval(()=>{
    bootPercent=Math.min(100,bootPercent+Math.max(4,Math.floor(5+Math.random()*11)));
    $('bootProgress').style.width=bootPercent+'%';
    $('bootStatus').textContent=bootSteps[Math.min(3,Math.floor(bootPercent/28))];
    if(bootPercent>=100){clearInterval(bootInterval);setTimeout(()=>{$('boot').classList.add('hidden');$('phone').classList.remove('hidden');},510);}
  },230);
})();
