package com.rostislav.rostdroid;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;

public class BrowserActivity extends Activity {
    private WebView web;
    private EditText address;
    private ProgressBar progress;

    private int dp(int value) { return (int)(getResources().getDisplayMetrics().density * value); }

    private String fixAddress(String input) {
        String value = input == null ? "" : input.trim();
        if (value.startsWith("https://")) return value;
        if (value.startsWith("http://")) return "https://" + value.substring(7);
        if (value.contains(" ") || !value.contains("."))
            return "https://www.google.com/search?q=" + android.net.Uri.encode(value);
        return "https://" + value;
    }

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(12, 21, 39));
        LinearLayout bar = new LinearLayout(this);
        bar.setPadding(dp(8), dp(9), dp(8), dp(8));
        bar.setGravity(Gravity.CENTER_VERTICAL);

        Button back = new Button(this);
        back.setText("‹");
        bar.addView(back, new LinearLayout.LayoutParams(dp(48), dp(48)));
        Button forward = new Button(this);
        forward.setText("›");
        bar.addView(forward, new LinearLayout.LayoutParams(dp(48), dp(48)));
        address = new EditText(this);
        address.setSingleLine(true);
        address.setTextColor(Color.WHITE);
        address.setHintTextColor(0xffa8b4cc);
        address.setHint("Адрес или поиск");
        address.setTextSize(14);
        address.setImeOptions(EditorInfo.IME_ACTION_GO);
        bar.addView(address, new LinearLayout.LayoutParams(0, dp(48), 1));
        Button go = new Button(this);
        go.setText("→");
        bar.addView(go, new LinearLayout.LayoutParams(dp(48), dp(48)));
        root.addView(bar);
        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        root.addView(progress, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(2)));
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(false);
        web.getSettings().setAllowContentAccess(false);
        web.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
        web.getSettings().setMixedContentMode(android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) { address.setText(url); }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String scheme = request.getUrl().getScheme();
                return !"https".equals(scheme);
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int p) { progress.setProgress(p); progress.setVisibility(p == 100 ? android.view.View.INVISIBLE : android.view.View.VISIBLE); }
        });
        root.addView(web, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        setContentView(root);
        back.setOnClickListener(v -> { if (web.canGoBack()) web.goBack(); else finish(); });
        forward.setOnClickListener(v -> { if (web.canGoForward()) web.goForward(); });
        go.setOnClickListener(v -> web.loadUrl(fixAddress(address.getText().toString())));
        address.setOnEditorActionListener((v, action, event) -> { web.loadUrl(fixAddress(address.getText().toString())); return true; });
        web.loadUrl("https://www.google.com");
    }

    @Override public void onBackPressed() { if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy() { if (web != null) web.destroy(); super.onDestroy(); }
}
