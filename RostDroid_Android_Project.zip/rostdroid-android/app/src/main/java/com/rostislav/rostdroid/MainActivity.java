package com.rostislav.rostdroid;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.Settings;
import android.provider.ContactsContract;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView desktop;

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);

        desktop = new WebView(this);
        desktop.setBackgroundColor(0xff07101e);
        desktop.getSettings().setJavaScriptEnabled(true);
        desktop.getSettings().setDomStorageEnabled(true);
        desktop.getSettings().setAllowFileAccess(true);
        desktop.getSettings().setAllowFileAccessFromFileURLs(false);
        desktop.getSettings().setAllowUniversalAccessFromFileURLs(false);
        desktop.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
        desktop.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !"file:///android_asset/rostdroid.html".equals(request.getUrl().toString());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return !"file:///android_asset/rostdroid.html".equals(url);
            }
        });
        desktop.addJavascriptInterface(new RostBridge(), "RostAndroid");
        setContentView(desktop);
        desktop.loadUrl("file:///android_asset/rostdroid.html");
    }

    private void launch(Intent intent) {
        try {
            startActivity(intent);
        } catch (ActivityNotFoundException | SecurityException e) {
            Toast.makeText(this, "Подходящее приложение не найдено", Toast.LENGTH_SHORT).show();
        }
    }

    private class RostBridge {
        @JavascriptInterface
        public void open(String what, String value) {
            runOnUiThread(() -> {
                String arg = value == null ? "" : value.trim();
                switch (what == null ? "" : what) {
                    case "browser":
                        startActivity(new Intent(MainActivity.this, BrowserActivity.class));
                        break;
                    case "phone":
                        launch(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + arg.replaceAll("[^0-9+#*]", ""))));
                        break;
                    case "messages":
                        launch(new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")));
                        break;
                    case "camera":
                        launch(new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA));
                        break;
                    case "gallery":
                        launch(new Intent(Intent.ACTION_GET_CONTENT).setType("image/*"));
                        break;
                    case "contacts":
                        launch(new Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI));
                        break;
                    case "files":
                        launch(new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"));
                        break;
                    case "maps":
                        launch(new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=moscow")));
                        break;
                    case "settings":
                        launch(new Intent(Settings.ACTION_SETTINGS));
                        break;
                    case "wifi":
                        launch(new Intent(Settings.ACTION_WIFI_SETTINGS));
                        break;
                    case "bluetooth":
                        launch(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
                        break;
                    case "playstore":
                        Intent play = new Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=apps"));
                        try {
                            startActivity(play);
                        } catch (ActivityNotFoundException exception) {
                            launch(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps")));
                        }
                        break;
                    default:
                        Toast.makeText(MainActivity.this, "Неизвестное действие", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    @Override
    public void onBackPressed() {
        if (desktop != null) desktop.evaluateJavascript("window.rostdroidBack && window.rostdroidBack()", null);
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (desktop != null) {
            desktop.removeJavascriptInterface("RostAndroid");
            desktop.destroy();
        }
        super.onDestroy();
    }
}
